<?php
// Heading
$_['heading_title'] = 'Layered Navigation';