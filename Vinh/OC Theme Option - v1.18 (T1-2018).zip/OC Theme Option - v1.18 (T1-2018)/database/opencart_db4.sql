DROP TABLE IF EXISTS `oc_home4`;
CREATE TABLE `oc_home4` (
  `home4_id` int(11) NOT NULL AUTO_INCREMENT,
  `home4_value` varchar(32) NOT NULL,
  PRIMARY KEY (`home4_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `oc_home4` (`home4_id`, `home4_value`) VALUES
(1, 'wwdawd'),
(2, 'aaaaaa'),
(3, 'baaddbbad');