DROP TABLE IF EXISTS `oc_home3`;
CREATE TABLE `oc_home3` (
  `home3_id` int(11) NOT NULL AUTO_INCREMENT,
  `home3_value` varchar(32) NOT NULL,
  PRIMARY KEY (`home3_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `oc_home3` (`home3_id`, `home3_value`) VALUES
(1, 'wwdawd'),
(2, 'aaaaaa'),
(3, 'baaddbbad');