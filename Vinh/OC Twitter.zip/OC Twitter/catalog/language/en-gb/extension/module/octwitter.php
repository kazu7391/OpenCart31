<?php
// Heading
$_['heading_title']    = 'Tweeter Page';