<?php
$_['text_vertical_bar'] = 'Vertical Menu';
$_['text_mobile_bar'] = 'Mobile Menu';